package com.example.project4.util;

import com.example.project4.bean.Order;
import com.example.project4.bean.StoreOrders;


public class StageManager {
    public static Order order = new Order();
    public static StoreOrders storeOrders = new StoreOrders();
    public static int order_num = 0;
}
