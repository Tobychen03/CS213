package com.example.project.util;

import com.example.project.bean.Order;
import com.example.project.bean.StoreOrders;


public class StageManager {
    public static Order order = new Order();
    public static StoreOrders storeOrders = new StoreOrders();
    public static int order_num = 1;
}
