package com.example.project.inter;

public interface Customizable {
    boolean add(Object obj);
    boolean remove(Object obj);
}
