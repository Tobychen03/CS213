/**
 * @author Tianle Chen tc822, Zesheng Zhang zz354
 */
public class RunProject1 {
    public static void main(String[] args) {
        new Kiosk().run();
    }
}