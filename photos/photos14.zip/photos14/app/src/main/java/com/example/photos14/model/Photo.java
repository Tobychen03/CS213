package com.example.photos14.model;


import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.ByteArrayOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Photo class
 * @author Tianle Chen, Chenyan Fan
 */
public class Photo implements Serializable {

    /**
     * serial ID
     */
    private static final long serialVersionUID = 1L;

    /**
     * path to store photo
     */
    private byte[] bitmap;
    /**
     * caption of photo
     */
    private String caption;
    /**
     * name of photo
     */
    private String name;

    /**
     * tags for photo
     */
    private List<Tags> tags;

    /**
     * 1 args Constructor for photo object
     */
    public Photo(Bitmap bitmap){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        this.bitmap = baos.toByteArray();
        tags = new ArrayList<>();
    }

    /**
     * 2 args Constructor for photo objects.
     *
     * @param bitmap    path
     * @param caption caption
     */
    public Photo(Bitmap bitmap, String caption) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        this.bitmap = baos.toByteArray();
        this.caption = caption;
        this.name = "";
        this.tags = new ArrayList<Tags>();
    }


    /**
     * 4 args Constructor for photo objects.
     *
     * @param bitmap    path
     * @param caption caption
     * @param name    name
     */
    public Photo(Bitmap bitmap, String caption, String name) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        this.bitmap = baos.toByteArray();
        this.caption = caption;
        this.name = name;
        this.tags = new ArrayList<Tags>();
    }


    /**
     * remove tag
     *
     * @param tag1 tag that need remove
     */
    public void removeTag(Tags tag1) {
        tags.remove(tag1);
    }


    /**
     * Getter for the file path for the photo.
     *
     * @return path
     */
    public Bitmap getBitmap() {
        Bitmap temp = BitmapFactory.decodeByteArray(bitmap, 0, bitmap.length);
        return temp;
    }

    /**
     * Getter for the photo caption.
     *
     * @return caption
     */
    public String getCaption() {
        return this.caption;
    }

    /**
     * Getter for the photo's name.
     *
     * @return name
     */
    public String getName() {
        return this.name;
    }


    /**
     * Gets the list of all tags related to this photo.
     *
     * @return tags
     */
    public List<Tags> getTags() {
        if(tags == null){
            return new ArrayList<>();
        }
        return this.tags;
    }

    /**
     * Setter for the photo's caption.
     *
     * @param caption caption
     */
    public void setCaption(String caption) {
        this.caption = caption;
    }

    /**
     * Setter for the photo's name.
     *
     * @param name name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Adds tag to the arraylist
     *
     * @param tag tag
     */
    public void addTag(Tags tag) {
        tags.add(tag);
    }

    /**
     * set tags
     */
    public void setTags(List<Tags> tags){
        this.tags.clear();
        for(Tags tag: tags){
            this.tags.add(tag);
        }
    }
}
