package com.example.photos14;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.photos14.model.Album;
import com.example.photos14.persistent.AlbumDB;
import com.example.photos14.persistent.info;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * main activity
 * @author Tianle Chen, Chenyan Fan
 */
public class MainActivity extends AppCompatActivity {

    /**
     * enter name of album
     */
    private EditText name_album;
    /**
     * add album
     */
    private Button add_album;
    /**
     * delete album
     */
    private Button delete_album;
    /**
     * rename album
     */
    private Button rename_album;
    /**
     * open album
     */
    private Button open_album;
    /**
     * list view to show picture
     */
    private ListView listView;
    /**
     * search photo
     */
    private Button search_button;
    /**
     * album list
     */
    private static List<Album> albumList = new ArrayList<>();


    /**
     * file
     */
    private static String filename = "albums.txt";

    /**
     * initial
     * @param savedInstanceState state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.album);
        name_album = findViewById(R.id.name_album);
        add_album = findViewById(R.id.add_album);
        delete_album = findViewById(R.id.delete_album);
        rename_album = findViewById(R.id.rename_album);
        open_album = findViewById(R.id.open_album);
        search_button = findViewById(R.id.search_button);
        listView = findViewById(R.id.listView);
        listView.setChoiceMode(listView.CHOICE_MODE_SINGLE);


        read();
        ArrayAdapter<Album> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, albumList);
        listView.setAdapter(adapter);
        add_album.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = name_album.getText().toString();
                if ("".equals(name.trim())) {
                    showAlert("Please enter the name of album.");
                    return;
                }
                for(Album album: albumList){
                    if (album.getName().equals(name)) {
                        showAlert("Album already exists.");
                        return;
                    }
                }
                albumList.add(new Album(name));
                save();
                adapter.notifyDataSetChanged();
            }
        });

        delete_album.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SparseBooleanArray checked = listView.getCheckedItemPositions();
                if (checked != null) {
                    for (int i = 0; i < checked.size(); i++) {
                        int position = checked.keyAt(i);
                        if (checked.get(position)) {
                            albumList.remove(position);
                            save();
                        }
                    }
                    adapter.notifyDataSetChanged();
                }
            }
        });

        rename_album.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = name_album.getText().toString();
                for(Album album: albumList){
                    if (album.getName().equals(name)) {
                        showAlert("Album already exists.");
                        return;
                    }
                }
                SparseBooleanArray checked = listView.getCheckedItemPositions();
                if (checked != null) {
                    for (int i = 0; i < checked.size(); i++) {
                        int position = checked.keyAt(i);
                        if (checked.get(position)) {
                            Album album = albumList.get(position);
                            album.setName(name);
                            save();
                        }
                    }
                    adapter.notifyDataSetChanged();
                }
            }
        });

        open_album.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SparseBooleanArray checked = listView.getCheckedItemPositions();
                if (checked != null) {
                    for (int i = 0; i < checked.size(); i++) {
                        int position = checked.keyAt(i);
                        if (checked.get(position)) {
//                            Album album = albumList.get(position);
                            info.album = position;
                            save();
                            Intent intent = new Intent(MainActivity.this, photosActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    }
                    adapter.notifyDataSetChanged();
                }
            }
        });

        search_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, searchActivity.class);
                startActivity(intent);
            }
        });
    }

    /**
     * message
     * @param message message
     */
    public void showAlert(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Alert");
        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }


    /**
     * save data
     */
    public void save(){
        try {
            FileOutputStream outputStream;
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
            objectOutputStream.writeObject(albumList);
            objectOutputStream.close();
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    /**
     * read data
     */
    public void read(){
        try {
            FileInputStream inputStream;
            ObjectInputStream objectInputStream;
            inputStream = openFileInput(filename);
            objectInputStream = new ObjectInputStream(inputStream);
            albumList = (List<Album>) objectInputStream.readObject();
            objectInputStream.close();
            inputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}