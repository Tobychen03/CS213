package com.example.photos14;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.example.photos14.model.Album;
import com.example.photos14.model.Photo;
import com.example.photos14.model.Tags;
import com.example.photos14.persistent.info;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * display activity
 * @author Tianle Chen, Chenyan Fan
 */
public class displayActivity extends AppCompatActivity {
    /**
     * image view
     */
    private ImageView imageView;
    /**
     * last picture
     */
    private Button back_picture;
    /**
     * next picture
     */
    private Button next_picture;
    /**
     * add tag
     */
    private Button add_tag;
    /**
     * delete tag
     */
    private Button delete_tag;
    /**
     * move photo
     */
    private Button move_photo;
    /**
     * back to photos
     */
    private Button return_last_page;
    /**
     * tags
     */
    private Spinner tag;
    /**
     * move to album
     */
    private Spinner move_album;
    /**
     * value
     */
    private EditText value;
    /**
     * tag list
     */
    private ListView tag_view;
    /**
     * album list
     */
    private List<Album> albumList = new ArrayList<>();
    /**
     * file
     */
    private static String filename = "albums.txt";
    /**
     * album
     */
    private Album album;
    /**
     * photo list
     */
    private List<Photo> photoList = new ArrayList<>();
    /**
     * tag list
     */
    private List<Tags> tagsList = new ArrayList<>();
    /**
     * photo
     */
    private Photo photo;
    /**
     * index
     */
    private int index;
    /**
     * adapter
     */
    private ArrayAdapter<Tags> adapter;
    /**
     * tag adapter
     */
    private ArrayAdapter<String> adapter2;
    /**
     * album adapter
     */
    private ArrayAdapter<Album> adapter3;


    /**
     * initial
     * @param savedInstanceState state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display);

        imageView = findViewById(R.id.imageView);
        back_picture = findViewById(R.id.back_picture);
        next_picture = findViewById(R.id.next_picture);
        add_tag = findViewById(R.id.add_tag);
        move_photo = findViewById(R.id.move_photo);
        delete_tag = findViewById(R.id.delete_tag);
        tag = findViewById(R.id.tag);
        move_album = findViewById(R.id.move_album);
        return_last_page = findViewById(R.id.return_last_page);
        value = findViewById(R.id.value);
        tag_view = findViewById(R.id.tag_view);
        tag_view.setChoiceMode(tag_view.CHOICE_MODE_SINGLE);
        index = info.photo;

        read();
        album = albumList.get(info.album);
        if(album != null){
            photoList = album.getPhotos();
        }
        loadList();



        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, tagsList);
        tag_view.setAdapter(adapter);

        String[] options = {"person","location"};
        adapter2 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, options);
        tag.setAdapter(adapter2);

        adapter3 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, albumList);
        move_album.setAdapter(adapter3);

        back_picture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(index > 0){
                    index--;
                }else{
                    return;
                }
                loadList();
                adapter.notifyDataSetChanged();
            }
        });

        next_picture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(index < photoList.size()-1){
                    index++;
                }else{
                    return;
                }
                loadList();
                adapter.notifyDataSetChanged();
            }
        });

        add_tag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = tag.getSelectedItem().toString();
                String text2 = value.getText().toString();
                if(text2.trim().equals("")){
                    return;
                }
                for(Tags tag: tagsList){
                    if(tag.getKey().equals(text) && tag.getVal().equals(text2)){
                        return;
                    }
                }
                tagsList.add(new Tags(text,text2));
                photo.setTags(tagsList);
                save();
                adapter.notifyDataSetChanged();
            }
        });

        return_last_page.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(displayActivity.this, photosActivity.class);
                startActivity(intent);
                finish();
            }
        });

        delete_tag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SparseBooleanArray checked = tag_view.getCheckedItemPositions();
                if (checked != null) {
                    for (int i = 0; i < checked.size(); i++) {
                        int position = checked.keyAt(i);
                        if (checked.get(position)) {
                            tagsList.remove(position);
                            photo.setTags(tagsList);
                            save();
                        }
                    }
                    adapter.notifyDataSetChanged();
                }
            }
        });

        move_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = move_album.getSelectedItemPosition();
                albumList.get(position).getPhotos().add(photo);
                photoList.remove(photo);
                if(index == photoList.size()){
                    index--;
                }
                save();
                if(index == -1){
                    imageView.setImageDrawable(null);
                    adapter.notifyDataSetChanged();
                    return;
                }
                loadList();
                adapter.notifyDataSetChanged();
            }
        });

    }

    /**
     * load list
     */
    public void loadList(){
        photo = photoList.get(index);
        imageView.setImageBitmap(Bitmap.createScaledBitmap(photo.getBitmap(),200,200,false));

        tagsList.clear();
        for(Tags tag: photo.getTags()){
            tagsList.add(tag);
        }

    }

    /**
     * save data
     */
    public void save(){
        try {
            FileOutputStream outputStream;
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
            objectOutputStream.writeObject(albumList);
            objectOutputStream.close();
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    /**
     * read data
     */
    public void read(){
        try {
            FileInputStream inputStream;
            ObjectInputStream objectInputStream;
            inputStream = openFileInput(filename);
            objectInputStream = new ObjectInputStream(inputStream);
            albumList = (List<Album>) objectInputStream.readObject();
            objectInputStream.close();
            inputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
