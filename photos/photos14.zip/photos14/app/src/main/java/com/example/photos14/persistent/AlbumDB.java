package com.example.photos14.persistent;

import com.example.photos14.model.Album;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * User persistent data
 * @author Tianle Chen, Chenyan Fan
 */
public class AlbumDB implements Serializable {

    /**
     * serial ID
     */
    private static final long serialVersionUID = 1L;

    /**
     * user album collection
     */
    private static List<Album> albumList = new ArrayList<>();

    /**
     * User data persistent file path
     */

    private final static String filePath;

    static {
        filePath = "albums.txt";
        File file = new File(filePath);
        if (file.exists()) {
            loadAlbumFromFile();
            System.out.println(1);
        } else {
            File newfile = new File(filePath);
            try {
                newfile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
            synchronous();
        }
    }


    /**
     * load data to album list
     */
    public static void loadAlbumFromFile() {
        try {
            FileInputStream fileInputStream = new FileInputStream(filePath);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            albumList = (ArrayList<Album>) objectInputStream.readObject();
            objectInputStream.close();
            fileInputStream.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }



    /**
     * get all album object
     * @return album list collection
     */
    public static List<Album> allAlbum() {
        return albumList;
    }

    /**
     * Get album by name
     * if not exist, return null object
     * @param albumname albumname
     * @return album object
     */
    public static Album getAlbum(String albumname) {
        for (Album album : albumList) {
            if (album.getName().equals(albumname)) {
                return album;
            }
        }
        return null;
    }

    /**
     * Add new album object
     * @param albumname username
     */
    public static void addAlbum(String albumname) {
        albumList.add(new Album(albumname));
        synchronous();
    }

    /**
     * Delete album if exists
     * @param albumname albumname
     */
    public static void deleteAlbum(String albumname) {
        Album checkUser = getAlbum(albumname);
        if (checkUser != null) {
            albumList.remove(checkUser);
        }
        synchronous();
    }

    /**
     * Synchronizing album data or save data
     */
    public static void synchronous() {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(filePath);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(albumList);
            objectOutputStream.close();
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
