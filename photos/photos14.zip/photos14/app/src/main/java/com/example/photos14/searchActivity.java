package com.example.photos14;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.photos14.adapter.BitmapAdapter;
import com.example.photos14.model.Album;
import com.example.photos14.model.Photo;
import com.example.photos14.model.Tags;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * search activity
 * @author Tianle Chen, Chenyan Fan
 */
public class searchActivity extends AppCompatActivity {
    /**
     * photo list
     */
    private ListView photo_list;
    /**
     * person name
     */
    private EditText person_text;
    /**
     * enter location
     */
    private EditText location_text;
    /**
     * search by person
     */
    private Button search_by_person;
    /**
     * search by location
     */
    private Button search_by_location;
    /**
     * back to album
     */
    private Button back_to_album;
    /**
     * search by both
     */
    private Button search_by_both;
    /**
     * disjunction
     */
    private Button disjunction;
    /**
     * album list
     */
    private List<Album> albumList = new ArrayList<>();
    /**
     * file
     */
    private static String filename = "albums.txt";
    /**
     * bitmap list
     */
    private List<Bitmap> bitmapList = new ArrayList<>();
    /**
     * adapter
     */
    private BitmapAdapter adapter;

    /**
     * initialize
     * @param savedInstanceState state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search);

        photo_list = findViewById(R.id.photo_list);
        person_text = findViewById(R.id.person_text);
        location_text = findViewById(R.id.location_text);
        search_by_person = findViewById(R.id.search_by_person);
        search_by_location = findViewById(R.id.search_by_location);
        back_to_album = findViewById(R.id.back_to_album);
        search_by_both = findViewById(R.id.search_by_both);
        disjunction = findViewById(R.id.disjunction);

        read();

        adapter = new BitmapAdapter(this, android.R.layout.simple_list_item_1, bitmapList);
        photo_list.setAdapter(adapter);

        search_by_person.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bitmapList.clear();
                String text = person_text.getText().toString();
                if(text.trim().equals("")){
                    adapter.notifyDataSetChanged();
                    return;
                }
                for(Album album: albumList){
                    for(Photo photo: album.getPhotos()){
                        for(Tags tags: photo.getTags()){
                            if(tags.getKey().equals("person") && tags.getVal().toLowerCase().contains(text.toLowerCase())){
                                bitmapList.add(photo.getBitmap());
                                break;
                            }
                        }
                    }
                }
                adapter.notifyDataSetChanged();
            }
        });

        search_by_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bitmapList.clear();
                String text = location_text.getText().toString();
                if(text.trim().equals("")){
                    adapter.notifyDataSetChanged();
                    return;
                }
                for(Album album: albumList){
                    for(Photo photo: album.getPhotos()){
                        for(Tags tags: photo.getTags()){
                            if(tags.getKey().equals("location") && tags.getVal().toLowerCase().contains(text.toLowerCase())){
                                bitmapList.add(photo.getBitmap());
                                break;
                            }
                        }
                    }
                }
                adapter.notifyDataSetChanged();
            }
        });

        search_by_both.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bitmapList.clear();
                String text = location_text.getText().toString();
                String text2 = person_text.getText().toString();
                if(text.trim().equals("") || text2.trim().equals("")){
                    adapter.notifyDataSetChanged();
                    return;
                }
                for(Album album: albumList){
                    for(Photo photo: album.getPhotos()){
                        boolean first = false;
                        boolean second = false;
                        for(Tags tags: photo.getTags()){
                            if(tags.getKey().equals("location") && tags.getVal().toLowerCase().contains(text.toLowerCase())){
                                first = true;
                            }
                            if(tags.getKey().equals("person") && tags.getVal().toLowerCase().contains(text2.toLowerCase())){
                                second = true;
                            }
                        }
                        if(first && second){
                            bitmapList.add(photo.getBitmap());
                        }
                    }
                }
                adapter.notifyDataSetChanged();
            }
        });

        disjunction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bitmapList.clear();
                String text = location_text.getText().toString();
                String text2 = person_text.getText().toString();
                if(text.trim().equals("") || text2.trim().equals("")){
                    adapter.notifyDataSetChanged();
                    return;
                }
                for(Album album: albumList){
                    for(Photo photo: album.getPhotos()){
                        boolean first = false;
                        boolean second = false;
                        for(Tags tags: photo.getTags()){
                            if(tags.getKey().equals("location") && tags.getVal().toLowerCase().contains(text.toLowerCase())){
                                first = true;
                            }
                            if(tags.getKey().equals("person") && tags.getVal().toLowerCase().contains(text2.toLowerCase())){
                                second = true;
                            }
                        }
                        if(first || second){
                            bitmapList.add(photo.getBitmap());
                        }
                    }
                }
                adapter.notifyDataSetChanged();
            }
        });

        back_to_album.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(searchActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }


    /**
     * save data
     */
    public void save(){
        try {
            FileOutputStream outputStream;
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
            objectOutputStream.writeObject(albumList);
            objectOutputStream.close();
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    /**
     * read data
     */
    public void read(){
        try {
            FileInputStream inputStream;
            ObjectInputStream objectInputStream;
            inputStream = openFileInput(filename);
            objectInputStream = new ObjectInputStream(inputStream);
            albumList = (List<Album>) objectInputStream.readObject();
            objectInputStream.close();
            inputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
