package com.example.photos14.persistent;

import com.example.photos14.model.Album;
import com.example.photos14.model.Photo;

import java.util.ArrayList;
import java.util.List;

/**
 * tool to record data
 * @author Tianle Chen, Chenyan Fan
 */
public class info {
    /**
     * get album position
     */
    public static int album = -1;
    /**
     * get photo position
     */
    public static int photo = -1;

}
