package com.example.photos14.model;

import android.annotation.SuppressLint;

import androidx.annotation.NonNull;

import java.io.Serializable;
import java.util.ArrayList;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;



/**
 * Album class
 * @author Tianle Chen, Chenyan Fan
 */
public class Album implements Serializable {
    /**
     * serial ID
     */
    private static final long serialVersionUID = -4143935150417416554L;
    /**
     * name of album
     */
    private String name;
    /**
     * photos in album
     */
    private ArrayList<Photo> photos;

    /**
     * photo number in album
     */
    public int photoNum = 0;

    /**
     * one arg constructor
     * @param name album name
     */
    public Album(String name){
        this.name = name;
        this.photos = new ArrayList<>();
    }

    /**
     * 2 args constructor for albums
     * @param name name
     * @param photos array of photos
     */
    public Album(String name, ArrayList<Photo> photos){
        this.name = name;
        this.photos = photos;
    }



    /**
     * update number of photos
     */
    public void updateNum(){
        photoNum = photos.size();
    }



    /**
     * Getter for the albums name.
     * @return album name
     */
    public String getName(){
        return this.name;
    }

    /**
     * Getter for the list of photos on this album.
     * @return photos
     */
    public ArrayList<Photo> getPhotos(){
        return this.photos;
    }

    /**
     * Adds a new photo to the photo list.
     * @param photo photo
     */
    public void addPhoto(Photo photo){
        this.photos.add(photo);
        updateNum();
    }

    /**
     * Removes photo from photo list.
     * @param photo photo
     */
    public void remPhoto(Photo photo){
        this.photos.remove(photo);
        updateNum();
    }

    /**
     * Setter for the album name.
     * @param name name
     */
    public void setName(String name){
        this.name = name;
    }

    /**
     * override toString method
     * @return information of album
     */
    @NonNull
    @Override
    public String toString(){
        updateNum();
        return "Name:"+this.name+" # of photo:"+this.photoNum;
    }
}