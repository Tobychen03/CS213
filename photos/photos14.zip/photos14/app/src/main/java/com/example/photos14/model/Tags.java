package com.example.photos14.model;

import java.io.Serializable;

/**
 * Tags class
 * @author Tianle Chen, Chenyan Fan
 */
public class Tags implements Serializable {
    /**
     * serial ID
     */
    private static final long serialVersionUID = -878596573030680851L;
    /**
     * tag
     */
    private String key;
    /**
     * value
     */
    private String val;

    /**
     * Constructor for tags.
     * @param key label
     * @param val value
     */
    public Tags(String key, String val){
        this.key = key;
        this.val = val;
    }

    /**
     * Get the type of tag (key).
     * @return key
     */
    public String getKey(){
        return this.key;
    }

    /**
     * Get the value of tag(val).
     * @return value
     */
    public String getVal(){
        return this.val;
    }

    /**
     * override toString method
     * @return information of tag
     */
    @Override
    public String toString(){
        return "{" + this.key + "} : " + this.val;
    }
}