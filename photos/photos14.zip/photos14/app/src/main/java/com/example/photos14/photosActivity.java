package com.example.photos14;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.photos14.adapter.BitmapAdapter;
import com.example.photos14.model.Album;
import com.example.photos14.model.Photo;
import com.example.photos14.persistent.info;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * photo activity
 * @author Tianle Chen, Chenyan Fan
 */
public class photosActivity extends AppCompatActivity {
    /**
     * photo list
     */
    private ListView photo_list;
    /**
     * add photo
     */
    private Button add_photo;
    /**
     * remove photo
     */
    private Button remove_photo;
    /**
     * display photo
     */
    private Button display_photo;
    /**
     * back to album
     */
    private Button back_album;
    /**
     * album list
     */
    private List<Album> albumList = new ArrayList<>();
    /**
     * photo list
     */
    private List<Photo> photoList = new ArrayList<>();
    /**
     * file
     */
    private static String filename = "albums.txt";
    /**
     * album
     */
    private Album album;
    /**
     * request code
     */
    private static final int REQUEST_CODE_SELECT_PHOTO = 1;
    /**
     * list of bitmap
     */
    private List<Bitmap> bitmapList = new ArrayList<>();
    /**
     * adapter
     */
    private BitmapAdapter adapter;

    /**
     * initialize
     * @param savedInstanceState state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.photos);

        photo_list = findViewById(R.id.photo_list);
        add_photo = findViewById(R.id.add_photo);
        remove_photo = findViewById(R.id.remove_photo);
        display_photo = findViewById(R.id.display_photo);
        photo_list.setChoiceMode(photo_list.CHOICE_MODE_SINGLE);
        back_album = findViewById(R.id.back_album);

        read();
        album = albumList.get(info.album);
        if(album != null){
            photoList = album.getPhotos();
        }

        loadPhotos();
        adapter = new BitmapAdapter(this, android.R.layout.simple_list_item_1, bitmapList);
        photo_list.setAdapter(adapter);

        add_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent, REQUEST_CODE_SELECT_PHOTO);
            }
        });

        back_album.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(photosActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        remove_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SparseBooleanArray checked = photo_list.getCheckedItemPositions();
                if (checked != null) {
                    for (int i = 0; i < checked.size(); i++) {
                        int position = checked.keyAt(i);
                        if (checked.get(position)) {
                            photoList.remove(position);
                            loadPhotos();
                            albumList.set(info.album, album);
                            save();
                        }
                    }
                    adapter.notifyDataSetChanged();
                }
            }
        });

        display_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SparseBooleanArray checked = photo_list.getCheckedItemPositions();
                if (checked != null) {
                    for (int i = 0; i < checked.size(); i++) {
                        int position = checked.keyAt(i);
                        if (checked.get(position)) {
                            info.photo = position;
                            save();
                            Intent intent = new Intent(photosActivity.this, displayActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    }
                    adapter.notifyDataSetChanged();
                }
            }
        });


    }

    /**
     * select photo
     * @param requestCode request code
     * @param resultCode result code
     * @param data data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_SELECT_PHOTO && resultCode == RESULT_OK) {
            Uri selectedImageUri = data.getData();
            ContentResolver cr =this.getContentResolver();
            try {
                Bitmap bitmap = BitmapFactory.decodeStream(cr.openInputStream(selectedImageUri));
                Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, 300, 300, false);
                bitmapList.add(scaledBitmap);
                photoList.add(new Photo(bitmap));
                adapter.notifyDataSetChanged();
                albumList.set(info.album, album);
                save();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * load photo
     */
    public void loadPhotos(){
        bitmapList.clear();
        for(Photo photo: photoList){
            bitmapList.add(photo.getBitmap());
        }

    }

    /**
     * save data
     */
    public void save(){
        try {
            FileOutputStream outputStream;
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
            objectOutputStream.writeObject(albumList);
            objectOutputStream.close();
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    /**
     * read data
     */
    public void read(){
        try {
            FileInputStream inputStream;
            ObjectInputStream objectInputStream;
            inputStream = openFileInput(filename);
            objectInputStream = new ObjectInputStream(inputStream);
            albumList = (List<Album>) objectInputStream.readObject();
            objectInputStream.close();
            inputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
